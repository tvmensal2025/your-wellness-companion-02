import React from 'react';
import HealthChatBot from './HealthChatBot';
import { useAuth } from '@/hooks/useAuth';

const SofiaFloatingButton: React.FC = () => {
  const { user } = useAuth();

  return (
    <>
      {/* Sofia Flutuante Original - HealthChatBot */}
      <HealthChatBot user={user} />
    </>
  );
};

export default SofiaFloatingButton;
