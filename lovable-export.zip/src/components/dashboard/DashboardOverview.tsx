import React, { useEffect, useState } from 'react';
import { LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { Heart, Activity, Droplets, Target, TrendingUp, Scale, Zap, Calendar, Award, Timer, Bluetooth, MessageCircle, Bot, Utensils } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { XiaomiScaleFlow } from '@/components/XiaomiScaleFlow';
import { useWeightMeasurement } from '@/hooks/useWeightMeasurement';
import { useUserGender } from '@/hooks/useUserGender';
import { supabase } from '@/integrations/supabase/client';
import { format } from 'date-fns';
import { PersonIcon, BodyCompositionIcon, HealthIndicatorIcon } from '@/components/ui/person-icon';
import { BodyEvolutionChart } from './BodyEvolutionChart';
import { useNavigate } from 'react-router-dom';
import { User } from '@supabase/supabase-js';
const weeklyStats = [{
  day: 'Seg',
  exercicio: 45,
  hidratacao: 1.8,
  sono: 7.5
}, {
  day: 'Ter',
  exercicio: 30,
  hidratacao: 2.1,
  sono: 8.0
}, {
  day: 'Qua',
  exercicio: 60,
  hidratacao: 2.0,
  sono: 7.0
}, {
  day: 'Qui',
  exercicio: 40,
  hidratacao: 1.9,
  sono: 7.5
}, {
  day: 'Sex',
  exercicio: 50,
  hidratacao: 2.2,
  sono: 8.5
}, {
  day: 'Sab',
  exercicio: 75,
  hidratacao: 2.0,
  sono: 9.0
}, {
  day: 'Dom',
  exercicio: 35,
  hidratacao: 1.7,
  sono: 8.0
}];
const chartConfig = {
  peso: {
    label: 'Peso',
    color: '#F97316'
  },
  meta: {
    label: 'Meta',
    color: '#10B981'
  },
  exercicio: {
    label: 'Exercício (min)',
    color: '#3B82F6'
  },
  hidratacao: {
    label: 'Hidratação (L)',
    color: '#06B6D4'
  },
  sono: {
    label: 'Sono (h)',
    color: '#8B5CF6'
  }
};
const StatCard = ({
  title,
  value,
  unit,
  change,
  icon: Icon,
  color,
  description
}: {
  title: string;
  value: string | number;
  unit?: string;
  change?: string;
  icon: React.ComponentType<{
    className?: string;
  }>;
  color: string;
  description?: string;
}) => <Card className="stat-card stat-card-responsive">
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
      <CardTitle className="text-base sm:text-lg font-medium text-muted-foreground">
        {title}
      </CardTitle>
      <Icon className={`h-5 w-5 sm:h-6 sm:w-6 ${color}`} />
    </CardHeader>
    <CardContent className="p-4 sm:p-6">
      <div className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-foreground">
        {value}
        {unit && <span className="text-lg sm:text-xl text-muted-foreground ml-2">{unit}</span>}
      </div>
      {change && <p className="text-sm sm:text-base text-muted-foreground">
          {change}
        </p>}
      {description && <p className="text-sm sm:text-base text-muted-foreground mt-2">
          {description}
        </p>}
    </CardContent>
  </Card>;
const DashboardOverview: React.FC = () => {
  const {
    measurements,
    stats,
    loading
  } = useWeightMeasurement();
  const [weightData, setWeightData] = useState<any[]>([]);
  const [bodyComposition, setBodyComposition] = useState<any[]>([]);
  const navigate = useNavigate();

  // Obter gênero do usuário
  const [user, setUser] = useState<User | null>(null);
  const {
    gender,
    loading: genderLoading
  } = useUserGender(user);

  // Carregar usuário atual
  useEffect(() => {
    const getCurrentUser = async () => {
      const {
        data: {
          user
        }
      } = await supabase.auth.getUser();
      setUser(user);
    };
    getCurrentUser();
  }, []);

  // Atualização em tempo real
  useEffect(() => {
    const channel = supabase.channel('weight-measurements-changes').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'weight_measurements'
    }, () => {
      // Recarregar dados quando houver mudanças
      window.location.reload();
    }).subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  // Preparar dados do gráfico de peso
  useEffect(() => {
    if (measurements.length > 0) {
      const last7Days = measurements.slice(-7).map(m => ({
        date: format(new Date(m.measurement_date || m.created_at), 'dd/MM'),
        peso: Number(m.peso_kg),
        meta: 70 // Meta fixa por enquanto
      }));
      setWeightData(last7Days);
    }
  }, [measurements]);

  // Preparar dados de composição corporal
  useEffect(() => {
    if (measurements.length > 0) {
      const latest = measurements[0];
      const composition = [{
        name: 'Massa Muscular',
        value: Number(latest.massa_muscular_kg) || 35,
        color: '#10B981'
      }, {
        name: 'Gordura',
        value: Number(latest.gordura_corporal_percent) || 20,
        color: '#F59E0B'
      }, {
        name: 'Água',
        value: Number(latest.agua_corporal_percent) || 45,
        color: '#3B82F6'
      }];
      setBodyComposition(composition);
    }
  }, [measurements]);

  // Calcular mudança de peso
  const weightChange = () => {
    if (measurements.length >= 2) {
      const current = Number(measurements[0].peso_kg);
      const previous = Number(measurements[1].peso_kg);
      const change = current - previous;
      return change > 0 ? `+${change.toFixed(1)}kg` : `${change.toFixed(1)}kg`;
    }
    return "Primeiro registro";
  };

  // Calcular classificação do IMC
  const getIMCClassification = (imc: number) => {
    if (imc < 18.5) return "Abaixo do peso";
    if (imc < 25) return "Normal";
    if (imc < 30) return "Sobrepeso";
    return "Obesidade";
  };
  return <div className="space-y-3 sm:space-y-4 animate-fade-up p-3 sm:p-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-2 sm:mb-3">
        <div>
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-foreground">Dashboard</h1>
          <p className="text-base sm:text-lg text-muted-foreground">Acompanhe sua jornada de saúde</p>
        </div>
        <Button className="btn-gradient text-cyan-400 h-10 sm:h-11 px-4 sm:px-6 text-base">
          <Calendar className="w-5 h-5 sm:w-6 sm:h-6 mr-2" />
          Hoje
        </Button>
      </div>

      {/* Quick Stats - Movido para o topo */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <Card className="stat-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
            <CardTitle className="text-base sm:text-lg font-medium text-muted-foreground text-center">
              Peso Atual
            </CardTitle>
            <Scale className="h-5 w-5 sm:h-6 sm:w-6 text-primary" />
          </CardHeader>
          <CardContent className="p-3 sm:p-4">
            <div className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-foreground text-center">
              {stats?.currentWeight || 'N/A'}
              <span className="text-lg sm:text-xl text-muted-foreground ml-2">kg</span>
            </div>
                          {weightChange() && <p className="text-sm sm:text-base text-muted-foreground text-center">
                {weightChange()}
              </p>}
            
            {/* Últimas medições */}
            {measurements.length > 0 && <div className="mt-3 sm:mt-4 space-y-1">
                <p className="text-sm sm:text-base text-muted-foreground font-medium text-center">Últimas medições:</p>
                {measurements.slice(0, 2).map((measurement, index) => <div key={index} className="flex justify-between items-center text-sm sm:text-base">
                    <span className="text-muted-foreground">
                      {format(new Date(measurement.measurement_date || measurement.created_at), 'dd/MM')}
                    </span>
                    <span className={`font-medium ${index === 0 ? 'text-primary' : 'text-muted-foreground'}`}>
                      {Number(measurement.peso_kg).toFixed(1)} kg
                    </span>
                  </div>)}
              </div>}
          </CardContent>
        </Card>
        <Card className="stat-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
            <CardTitle className="text-base sm:text-lg font-medium text-muted-foreground text-center">
              IMC
            </CardTitle>
            <Target className="h-5 w-5 sm:h-6 sm:w-6 text-success" />
          </CardHeader>
          <CardContent className="p-3 sm:p-4">
            <div className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-foreground text-center">
              {stats?.currentIMC || 'N/A'}
            </div>
            {stats?.currentIMC && <p className="text-sm sm:text-base text-muted-foreground text-center">
                {getIMCClassification(stats.currentIMC)}
              </p>}
            <p className="text-sm sm:text-base text-muted-foreground mt-1 text-center">
              Índice de massa corporal
            </p>
          </CardContent>
        </Card>
        <Card className="stat-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
            <CardTitle className="text-base sm:text-lg font-medium text-muted-foreground text-center">
              Progresso Semanal
            </CardTitle>
            <Award className="h-5 w-5 sm:h-6 sm:w-6 text-yellow-500" />
          </CardHeader>
          <CardContent className="p-3 sm:p-4">
            <div className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-foreground text-center">
              78%
              <span className="text-lg sm:text-xl text-muted-foreground ml-2">Meta</span>
            </div>
            <div className="mt-3 space-y-1 sm:space-y-2">
              {/* Resumo da semana */}
              <div className="flex justify-between items-center text-sm sm:text-base">
                <span className="text-muted-foreground">Peso:</span>
                <span className="font-medium text-green-500">-1.2kg</span>
              </div>
              <div className="flex justify-between items-center text-sm sm:text-base">
                <span className="text-muted-foreground">Exercícios:</span>
                <span className="font-medium text-blue-500">5/7 dias</span>
              </div>
              <div className="flex justify-between items-center text-sm sm:text-base">
                <span className="text-muted-foreground">Hidratação:</span>
                <span className="font-medium text-cyan-500">85%</span>
              </div>
            </div>
            <div className="mt-3 sm:mt-4">
              <div className="flex justify-between items-center text-sm sm:text-base mb-2">
                <span className="text-muted-foreground">Progresso Geral</span>
                <span className="font-medium">78%</span>
              </div>
              <Progress value={78} className="h-3" />
            </div>
            <p className="text-sm sm:text-base text-muted-foreground mt-3">
              Tendência: <span className="text-green-500 font-medium">↗️ Positiva</span>
            </p>
          </CardContent>
        </Card>
        <Card className="stat-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
            <CardTitle className="text-base sm:text-lg font-medium text-muted-foreground text-center">
              Pesagem
            </CardTitle>
            <div className="flex items-center gap-2">
              <Bluetooth className="h-5 w-5 sm:h-6 sm:w-6 text-blue-500" />
              <MessageCircle className="h-5 w-5 sm:h-6 sm:w-6 text-purple-500" />
            </div>
          </CardHeader>
          <CardContent className="p-3 sm:p-4 pt-2">
            <div className="text-center mb-2">
              <Scale className="h-12 w-12 text-primary mx-auto mb-2" />
              <p className="text-xs text-muted-foreground">Balança Xiaomi</p>
            </div>
            <XiaomiScaleFlow />
          </CardContent>
        </Card>
      </div>

      {/* Main Charts - Body Evolution */}
      <div className="grid grid-cols-1 gap-4">
        <BodyEvolutionChart weightData={weightData.map((item, index) => ({
        date: item.date,
        time: '08:30',
        // Hora padrão
        value: item.peso,
        type: 'peso' as const
      }))} bodyCompositionData={{
        gordura: 44.1,
        musculo: 24.0,
        agua: 39.9,
        osso: 15.0
      }} userGender={gender} />
      </div>

      {/* Weekly Activity Chart */}
      <Card className="health-card">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Activity className="w-5 h-5 text-health-steps" />
            <span>Atividade Semanal</span>
          </CardTitle>
          <CardDescription>
            Exercício, hidratação e qualidade do sono
          </CardDescription>
        </CardHeader>
        <CardContent className="p-2 sm:p-4">
          <div className="h-80 sm:h-96 lg:h-[500px] -mx-8 sm:-mx-10 lg:-mx-12">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={weeklyStats} barSize={20} barGap={8} barCategoryGap={20}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" strokeOpacity={0.2} />
                <XAxis 
                  dataKey="day" 
                  stroke="hsl(var(--muted-foreground))" 
                  fontSize={16}
                  axisLine={false}
                  tickLine={false}
                  padding={{ left: 5, right: 5 }}
                />
                <YAxis 
                  stroke="hsl(var(--muted-foreground))" 
                  fontSize={16}
                  axisLine={false}
                  tickLine={false}
                  padding={{ top: 5, bottom: 5 }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--background))', 
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px',
                    fontSize: '14px'
                  }}
                />
                <Legend 
                  wrapperStyle={{ fontSize: '14px', paddingTop: '10px' }}
                />
                <Bar 
                  dataKey="exercicio" 
                  fill="hsl(var(--health-steps))" 
                  radius={[4, 4, 0, 0]}
                  stroke="hsl(var(--health-steps))"
                  strokeWidth={1}
                />
                <Bar 
                  dataKey="hidratacao" 
                  fill="hsl(var(--health-hydration))" 
                  radius={[4, 4, 0, 0]}
                  stroke="hsl(var(--health-hydration))"
                  strokeWidth={1}
                />
                <Bar 
                  dataKey="sono" 
                  fill="hsl(var(--accent))" 
                  radius={[4, 4, 0, 0]}
                  stroke="hsl(var(--accent))"
                  strokeWidth={1}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Quick Access - Sofia */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 mb-4">
        <Card className="mission-card hover:shadow-lg transition-shadow cursor-pointer" onClick={() => window.location.href = '/sofia'}>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center space-x-2">
              <MessageCircle className="w-4 h-4 text-green-600" />
              <span>Sofia Chat</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Bot className="w-5 h-5 text-green-500" />
                <span className="text-sm font-medium">Assistente IA</span>
              </div>
              <p className="text-xs text-muted-foreground">Converse com a Sofia sobre nutrição e saúde</p>
              <div className="flex items-center space-x-1 mt-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-xs text-green-600">Online</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="mission-card hover:shadow-lg transition-shadow cursor-pointer" onClick={() => window.location.href = '/sofia-nutricional'}>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center space-x-2">
              <Utensils className="w-4 h-4 text-emerald-600" />
              <span>Sofia Nutricional</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Target className="w-5 h-5 text-emerald-500" />
                <span className="text-sm font-medium">Planejamento</span>
              </div>
              <p className="text-xs text-muted-foreground">Planeje suas refeições e acompanhe nutrição</p>
              <div className="flex items-center space-x-1 mt-2">
                <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
                <span className="text-xs text-emerald-600">Disponível</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="mission-card hover:shadow-lg transition-shadow cursor-pointer" onClick={() => window.location.href = '/app/missions'}>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center space-x-2">
              <Activity className="w-4 h-4 text-blue-600" />
              <span>Missão do Dia</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Award className="w-5 h-5 text-blue-500" />
                <span className="text-sm font-medium">Gamificação</span>
              </div>
              <p className="text-xs text-muted-foreground">Complete missões e ganhe pontos</p>
              <div className="flex items-center space-x-1 mt-2">
                <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                <span className="text-xs text-blue-600">Nova missão</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Daily Goals Progress */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        <Card className="mission-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center space-x-2">
              <Heart className="w-4 h-4 text-health-heart" />
              <span>Exercício Diário</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>45 min</span>
                <span>Meta: 30 min</span>
              </div>
              <Progress value={150} className="h-2" />
              <p className="text-xs text-success font-medium">Meta superada! 🎉</p>
            </div>
          </CardContent>
        </Card>

        <Card className="mission-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center space-x-2">
              <Droplets className="w-4 h-4 text-health-hydration" />
              <span>Hidratação</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>1.8 L</span>
                <span>Meta: 2.0 L</span>
              </div>
              <Progress value={90} className="h-2" />
              <p className="text-xs text-muted-foreground">Falta apenas 200ml</p>
            </div>
          </CardContent>
        </Card>

        <Card className="mission-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center space-x-2">
              <Timer className="w-4 h-4 text-accent" />
              <span>Sono</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>7.5 h</span>
                <span>Meta: 8.0 h</span>
              </div>
              <Progress value={94} className="h-2" />
              <p className="text-xs text-muted-foreground">Quase na meta!</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>;
};
export default DashboardOverview;