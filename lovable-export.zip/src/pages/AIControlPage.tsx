import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Mic, 
  Volume2, 
  Settings, 
  DollarSign, 
  Activity, 
  Brain,
  ArrowLeft,
  Home
} from 'lucide-react';
import { Link } from 'react-router-dom';
import AIControlPanel from '@/components/admin/AIControlPanel';
import AITestPanel from '@/components/admin/AITestPanel';

export default function AIControlPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Link to="/admin">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Voltar ao Admin
                </Button>
              </Link>
              <Link to="/">
                <Button variant="ghost" size="sm">
                  <Home className="w-4 h-4 mr-2" />
                  Home
                </Button>
              </Link>
            </div>
            
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="text-sm">
                <Activity className="w-4 h-4 mr-2" />
                Sistema Ativo
              </Badge>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <div className="flex items-center space-x-4 mb-4">
            <div className="p-3 bg-blue-100 rounded-lg">
              <Brain className="w-8 h-8 text-blue-600" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                Controle de IA - Sofia
              </h1>
              <p className="text-gray-600 mt-1">
                Gerencie a voz da Sofia e monitore custos de IA
              </p>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Status da Voz</CardTitle>
              <Mic className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">Ativa</div>
              <p className="text-xs text-muted-foreground">
                Google TTS funcionando
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Velocidade</CardTitle>
              <Volume2 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">0.85</div>
              <p className="text-xs text-muted-foreground">
                Velocidade atual
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Custo Hoje</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">$0.00</div>
              <p className="text-xs text-muted-foreground">
                Sem uso registrado
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Configurações</CardTitle>
              <Settings className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">2</div>
              <p className="text-xs text-muted-foreground">
                Painéis disponíveis
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Main Panels */}
        <div className="space-y-8">
          {/* Test Panel */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Volume2 className="w-5 h-5 mr-2" />
                Teste Rápido de Voz
              </CardTitle>
              <CardDescription>
                Ajuste a velocidade, tom e volume da Sofia em tempo real
              </CardDescription>
            </CardHeader>
            <CardContent>
              <AITestPanel />
            </CardContent>
          </Card>

          {/* Full Control Panel */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Settings className="w-5 h-5 mr-2" />
                Painel de Controle Completo
              </CardTitle>
              <CardDescription>
                Configurações avançadas, monitoramento de custos e gerenciamento de IA
              </CardDescription>
            </CardHeader>
            <CardContent>
              <AIControlPanel />
            </CardContent>
          </Card>
        </div>

        {/* Instructions */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Como Usar</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-2">🎤 Teste Rápido</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Use os controles deslizantes para ajustar</li>
                  <li>• Digite texto personalizado para testar</li>
                  <li>• Clique em "Testar Voz" para ouvir</li>
                  <li>• Ajuste até encontrar a configuração ideal</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2">⚙️ Controle Completo</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Salve configurações no banco de dados</li>
                  <li>• Monitore custos e uso de IA</li>
                  <li>• Veja estatísticas detalhadas</li>
                  <li>• Gerencie múltiplas configurações</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
