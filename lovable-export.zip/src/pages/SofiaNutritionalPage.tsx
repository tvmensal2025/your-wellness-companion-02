import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { 
  Calendar, 
  Target, 
  TrendingUp, 
  Apple, 
  BarChart3,
  ChefHat,
  Lightbulb,
  Zap,
  UtensilsCrossed,
  History,
  Plus
} from 'lucide-react';

import { MealPlanGeneratorModal } from '@/components/nutrition-tracking/MealPlanGeneratorModal';
import { MealPlanHistoryModal } from '@/components/meal-plan/MealPlanHistoryModal';
import { useNutritionTracking } from '@/hooks/useNutritionTracking';
import { findSuperfoods, findFoodsByDiet } from '@/data/open-nutri-tracker-database';

import { SofiaNutritionInsights } from '@/components/sofia/SofiaNutritionInsights';

export const SofiaNutritionalPage: React.FC = () => {
  const { meals, goals, loading, error, getDailyNutrition, getNutritionStats } = useNutritionTracking();
  const [selectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [activeTab, setActiveTab] = useState('cardapio');
  const [generatorModalOpen, setGeneratorModalOpen] = useState(false);
  const [historyModalOpen, setHistoryModalOpen] = useState(false);
  
  // Estado para controlar quais refeições incluir no cardápio
  const [selectedMeals, setSelectedMeals] = useState({
    'café da manhã': true,
    'almoço': true,
    'lanche': true,
    'jantar': true,
    'ceia': false
  });

  // Função para alternar seleção de refeição
  const toggleMealSelection = (mealType: string) => {
    setSelectedMeals(prev => ({
      ...prev,
      [mealType]: !prev[mealType as keyof typeof prev]
    }));
  };

  // Função para gerar cardápio com refeições selecionadas
  const handleGenerateMealPlan = () => {
    // Verificar se pelo menos uma refeição está selecionada
    const hasSelectedMeals = Object.values(selectedMeals).some(selected => selected);
    
    if (!hasSelectedMeals) {
      // Mostrar erro se nenhuma refeição estiver selecionada
      alert('Selecione pelo menos uma refeição para gerar o cardápio.');
      return;
    }

    // Abrir modal de geração com as refeições selecionadas
    setGeneratorModalOpen(true);
  };

  // Calcular distribuição de calorias baseada nas refeições selecionadas
  const getCalorieDistribution = () => {
    const selectedMealTypes = Object.keys(selectedMeals).filter(meal => selectedMeals[meal as keyof typeof selectedMeals]);
    const totalMeals = selectedMealTypes.length;
    
    if (totalMeals === 0) return {};
    
    // Distribuição padrão para 5 refeições
    const defaultDistribution = {
      'café da manhã': 0.25,
      'almoço': 0.35,
      'lanche': 0.15,
      'jantar': 0.20,
      'ceia': 0.05
    };
    
    // Recalcular distribuição baseada nas refeições selecionadas
    const distribution: { [key: string]: number } = {};
    let totalPercentage = 0;
    
    selectedMealTypes.forEach(mealType => {
      totalPercentage += defaultDistribution[mealType as keyof typeof defaultDistribution] || 0;
    });
    
    // Normalizar para 100%
    selectedMealTypes.forEach(mealType => {
      const originalPercentage = defaultDistribution[mealType as keyof typeof defaultDistribution] || 0;
      distribution[mealType] = originalPercentage / totalPercentage;
    });
    
    return distribution;
  };

  const stats = getNutritionStats(7);
  const dailyNutrition = getDailyNutrition(selectedDate);
  const superfoods = findSuperfoods();
  const ketoFoods = findFoodsByDiet('keto');

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-purple-50 p-3 sm:p-4">
      {/* Top Banner simplificado (sem perfil/host) */}
      <div className="bg-gradient-to-r from-emerald-500 via-green-500 to-emerald-600 rounded-2xl p-4 sm:p-6 mb-4 sm:mb-6 text-white text-center">
        <h1 className="text-xl sm:text-2xl font-bold">Ψ Sofia Nutricional</h1>
        <p className="text-emerald-100 mt-1 text-sm sm:text-base">Planejamento inteligente com garantia de metas</p>
      </div>

      {/* Nutritional Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 mb-4 sm:mb-6">
        <Card className="bg-white shadow-sm border-0">
          <CardContent className="p-3 sm:p-4">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xs sm:text-sm font-medium text-gray-600">Calorias</h3>
              <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-500" />
            </div>
            <div className="text-lg sm:text-xl font-bold text-gray-900 truncate">{dailyNutrition.totalCalories}</div>
            <div className="text-xs sm:text-sm text-gray-500 mt-1 truncate">Meta: {goals.calories} kcal</div>
            <Progress value={Math.min(dailyNutrition.progress.calories, 100)} className="mt-2 h-2 sm:h-3 bg-gray-100" />
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-0">
          <CardContent className="p-3 sm:p-4">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xs sm:text-sm font-medium text-gray-600">Proteínas</h3>
              <Apple className="w-4 h-4 sm:w-5 sm:h-5 text-green-500" />
            </div>
            <div className="text-lg sm:text-xl font-bold text-gray-900 truncate">{dailyNutrition.totalProtein}g</div>
            <div className="text-xs sm:text-sm text-gray-500 mt-1 truncate">Meta: {goals.protein}g</div>
            <Progress value={Math.min(dailyNutrition.progress.protein, 100)} className="mt-2 h-2 sm:h-3 bg-gray-100" />
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-0">
          <CardContent className="p-3 sm:p-4">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xs sm:text-sm font-medium text-gray-600">Carboidratos</h3>
              <BarChart3 className="w-4 h-4 sm:w-5 sm:h-5 text-yellow-500" />
            </div>
            <div className="text-lg sm:text-xl font-bold text-gray-900 truncate">{dailyNutrition.totalCarbs}g</div>
            <div className="text-xs sm:text-sm text-gray-500 mt-1 truncate">Meta: {goals.carbs}g</div>
            <Progress value={Math.min(dailyNutrition.progress.carbs, 100)} className="mt-2 h-2 sm:h-3 bg-gray-100" />
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-0">
          <CardContent className="p-3 sm:p-4">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xs sm:text-sm font-medium text-gray-600">Gorduras</h3>
              <Target className="w-4 h-4 sm:w-5 sm:h-5 text-red-500" />
            </div>
            <div className="text-lg sm:text-xl font-bold text-gray-900 truncate">{dailyNutrition.totalFat}g</div>
            <div className="text-xs sm:text-sm text-gray-500 mt-1 truncate">Meta: {goals.fat}g</div>
            <Progress value={Math.min(dailyNutrition.progress.fat, 100)} className="mt-2 h-2 sm:h-3 bg-gray-100" />
          </CardContent>
        </Card>
      </div>

      {/* Tabs de Navegação */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4 mb-4 sm:mb-6">
          <TabsTrigger value="cardapio" className="text-xs px-2 sm:px-3">Cardápio</TabsTrigger>
          <TabsTrigger value="estatisticas" className="text-xs px-2 sm:px-3">Estatísticas</TabsTrigger>
          <TabsTrigger value="insights" className="text-xs px-2 sm:px-3">Insights</TabsTrigger>
          <TabsTrigger value="metas" className="text-xs px-2 sm:px-3">Metas</TabsTrigger>
        </TabsList>



        <TabsContent value="cardapio" className="space-y-4 sm:space-y-6">
          <Card className="bg-white shadow-sm border-0">
            <CardHeader className="p-4 sm:p-6">
              <CardTitle className="flex items-center justify-center gap-2 text-lg sm:text-xl">
                <UtensilsCrossed className="w-5 h-5 sm:w-6 sm:h-6 text-emerald-600" />
                Cardápio Semanal
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Gera 7 dias respeitando suas metas
              </p>
            </CardHeader>
            <CardContent className="mobile-padding space-y-6">
              {/* Checkboxes das refeições */}
              <div className="space-y-3">
                <h3 className="font-medium text-foreground">Refeições incluídas:</h3>
                <div className="grid grid-cols-2 gap-3">
                  <div 
                    className={`flex items-center space-x-2 p-2 rounded-lg cursor-pointer transition-colors ${
                      selectedMeals['café da manhã'] 
                        ? 'bg-emerald-50 border border-emerald-200' 
                        : 'bg-gray-50 border border-gray-200'
                    }`}
                    onClick={() => toggleMealSelection('café da manhã')}
                  >
                    <div className={`w-4 h-4 rounded-full flex items-center justify-center transition-colors ${
                      selectedMeals['café da manhã'] 
                        ? 'bg-emerald-500' 
                        : 'bg-gray-300'
                    }`}>
                      {selectedMeals['café da manhã'] && (
                        <div className="w-2 h-2 rounded-full bg-white"></div>
                      )}
                    </div>
                    <span className="text-sm">Café da manhã</span>
                  </div>
                  
                  <div 
                    className={`flex items-center space-x-2 p-2 rounded-lg cursor-pointer transition-colors ${
                      selectedMeals['almoço'] 
                        ? 'bg-emerald-50 border border-emerald-200' 
                        : 'bg-gray-50 border border-gray-200'
                    }`}
                    onClick={() => toggleMealSelection('almoço')}
                  >
                    <div className={`w-4 h-4 rounded-full flex items-center justify-center transition-colors ${
                      selectedMeals['almoço'] 
                        ? 'bg-emerald-500' 
                        : 'bg-gray-300'
                    }`}>
                      {selectedMeals['almoço'] && (
                        <div className="w-2 h-2 rounded-full bg-white"></div>
                      )}
                    </div>
                    <span className="text-sm">Almoço</span>
                  </div>
                  
                  <div 
                    className={`flex items-center space-x-2 p-2 rounded-lg cursor-pointer transition-colors ${
                      selectedMeals['lanche'] 
                        ? 'bg-emerald-50 border border-emerald-200' 
                        : 'bg-gray-50 border border-gray-200'
                    }`}
                    onClick={() => toggleMealSelection('lanche')}
                  >
                    <div className={`w-4 h-4 rounded-full flex items-center justify-center transition-colors ${
                      selectedMeals['lanche'] 
                        ? 'bg-emerald-500' 
                        : 'bg-gray-300'
                    }`}>
                      {selectedMeals['lanche'] && (
                        <div className="w-2 h-2 rounded-full bg-white"></div>
                      )}
                    </div>
                    <span className="text-sm">Lanche</span>
                  </div>
                  
                  <div 
                    className={`flex items-center space-x-2 p-2 rounded-lg cursor-pointer transition-colors ${
                      selectedMeals['jantar'] 
                        ? 'bg-emerald-50 border border-emerald-200' 
                        : 'bg-gray-50 border border-gray-200'
                    }`}
                    onClick={() => toggleMealSelection('jantar')}
                  >
                    <div className={`w-4 h-4 rounded-full flex items-center justify-center transition-colors ${
                      selectedMeals['jantar'] 
                        ? 'bg-emerald-500' 
                        : 'bg-gray-300'
                    }`}>
                      {selectedMeals['jantar'] && (
                        <div className="w-2 h-2 rounded-full bg-white"></div>
                      )}
                    </div>
                    <span className="text-sm">Jantar</span>
                  </div>
                  
                  <div 
                    className={`flex items-center space-x-2 p-2 rounded-lg cursor-pointer transition-colors ${
                      selectedMeals['ceia'] 
                        ? 'bg-emerald-50 border border-emerald-200' 
                        : 'bg-gray-50 border border-gray-200'
                    }`}
                    onClick={() => toggleMealSelection('ceia')}
                  >
                    <div className={`w-4 h-4 rounded-full flex items-center justify-center transition-colors ${
                      selectedMeals['ceia'] 
                        ? 'bg-emerald-500' 
                        : 'bg-gray-300'
                    }`}>
                      {selectedMeals['ceia'] && (
                        <div className="w-2 h-2 rounded-full bg-white"></div>
                      )}
                    </div>
                    <span className="text-sm">Ceia</span>
                  </div>
                </div>
                
                {/* Informação sobre distribuição de calorias */}
                <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                  <p className="text-xs text-blue-700">
                    <strong>Distribuição de calorias:</strong> {Object.keys(selectedMeals).filter(meal => selectedMeals[meal as keyof typeof selectedMeals]).length} refeições selecionadas
                  </p>
                  {Object.keys(selectedMeals).filter(meal => selectedMeals[meal as keyof typeof selectedMeals]).length > 0 && (
                    <div className="mt-2 text-xs text-blue-600">
                      {Object.entries(getCalorieDistribution()).map(([meal, percentage]) => (
                        <div key={meal} className="flex justify-between">
                          <span>{meal}:</span>
                          <span>{Math.round(percentage * 100)}%</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Botões de ação */}
              <div className="flex flex-col sm:flex-row gap-3">
                <Button 
                  onClick={handleGenerateMealPlan}
                  className="flex-1 bg-gradient-to-r from-emerald-500 to-purple-600 hover:from-emerald-600 hover:to-purple-700 text-white"
                >
                  Gerar Cardápio
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => setHistoryModalOpen(true)}
                  className="flex-1"
                >
                  Abrir Cardápio
                </Button>
                <Button 
                  variant="outline" 
                  className="flex-1"
                >
                  Abrir Cardápio (Clínico)
                </Button>
              </div>

              {/* Status */}
              <div className="text-center py-8 text-muted-foreground">
                Nenhum cardápio gerado ainda.
              </div>

              {/* Histórico de cardápios */}
              <div className="border-t pt-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-medium text-foreground">Histórico de cardápios salvos</h3>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => setHistoryModalOpen(true)}
                  >
                    <History className="w-4 h-4 mr-2" />
                    Ver Histórico
                  </Button>
                </div>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <div className="flex justify-between items-center py-2 border-b">
                    <span>20/08/2025</span>
                    <span>2000 kcal</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b">
                    <span>20/08/2025</span>
                    <span>2000 kcal</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b">
                    <span>19/08/2025</span>
                    <span>2000 kcal</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b">
                    <span>19/08/2025</span>
                    <span>2000 kcal</span>
                  </div>
                  <div className="flex justify-between items-center py-2">
                    <span>19/08/2025</span>
                    <span>2000 kcal</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="estatisticas" className="space-y-4 sm:space-y-6">
          <Card className="bg-white shadow-sm border-0">
            <CardHeader className="p-4 sm:p-6">
              <CardTitle className="flex items-center justify-center gap-2 text-lg sm:text-xl">
                <BarChart3 className="w-5 h-5 sm:w-6 sm:h-6 text-emerald-600" />
                Estatísticas Nutricionais
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4 sm:p-6">
              <div className="text-center py-8 text-muted-foreground">
                Estatísticas em desenvolvimento...
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="insights" className="space-y-4 sm:space-y-6">
          <SofiaNutritionInsights />
        </TabsContent>

        <TabsContent value="metas" className="space-y-4 sm:space-y-6">
          <Card className="bg-white shadow-sm border-0">
            <CardHeader className="p-4 sm:p-6">
              <CardTitle className="flex items-center justify-center gap-2 text-lg sm:text-xl">
                <Target className="w-5 h-5 sm:w-6 sm:h-6 text-emerald-600" />
                Metas Nutricionais
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4 sm:p-6">
              <div className="text-center py-8 text-muted-foreground">
                Configuração de metas em desenvolvimento...
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Modals */}
      <MealPlanGeneratorModal
        open={generatorModalOpen}
        onOpenChange={setGeneratorModalOpen}
        selectedMeals={selectedMeals}
      />
      
      {historyModalOpen && <MealPlanHistoryModal />}
    </div>
  );
};
