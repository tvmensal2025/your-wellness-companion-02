import React from 'react';
import { GoogleFitConnect } from '@/components/GoogleFitConnect';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export const GoogleFitPage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => navigate(-1)}
            className="mb-4"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Voltar
          </Button>
          
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Integração Google Fit
          </h1>
          <p className="text-gray-600">
            Conecte sua conta Google Fit para sincronizar dados de saúde automaticamente
          </p>
        </div>

        {/* Componente de conexão */}
        <GoogleFitConnect />

        {/* Botão de teste de configuração */}
        <div className="mt-6 text-center">
          <Button 
            variant="outline" 
            onClick={async () => {
              try {
                const response = await fetch('https://hlrkoyywjpckdotimtik.supabase.co/functions/v1/test-google-fit-config', {
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${process.env.REACT_APP_SUPABASE_ANON_KEY}`
                  }
                });
                const data = await response.json();
                alert(JSON.stringify(data, null, 2));
              } catch (error) {
                alert('Erro ao testar: ' + error.message);
              }
            }}
          >
            🔧 Testar Configuração
          </Button>
        </div>

        {/* Informações adicionais */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <h3 className="font-semibold text-lg mb-3">📊 Dados Sincronizados</h3>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>• Passos diários e distância</li>
              <li>• Calorias ativas e totais</li>
              <li>• Minutos de atividade física</li>
              <li>• Dados de sono</li>
              <li>• Frequência cardíaca</li>
              <li>• Peso e composição corporal</li>
            </ul>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <h3 className="font-semibold text-lg mb-3">🔒 Segurança</h3>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>• Autorização única via Google</li>
              <li>• Dados criptografados no Supabase</li>
              <li>• Você pode revogar acesso a qualquer momento</li>
              <li>• Não compartilhamos dados com terceiros</li>
              <li>• Conformidade com LGPD</li>
            </ul>
          </div>
        </div>

        {/* Prévia do painel */}
        <div className="mt-8 bg-white p-6 rounded-lg shadow-sm border">
          <h3 className="font-semibold text-lg mb-4">📈 Prévia do painel</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <p className="text-sm font-medium text-blue-800">Passos (hoje)</p>
              <div className="h-8 bg-blue-200 rounded mt-2 animate-pulse"></div>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <p className="text-sm font-medium text-green-800">Calorias ativas</p>
              <div className="h-8 bg-green-200 rounded mt-2 animate-pulse"></div>
            </div>
            <div className="text-center p-4 bg-yellow-50 rounded-lg">
              <p className="text-sm font-medium text-yellow-800">Minutos ativos</p>
              <div className="h-8 bg-yellow-200 rounded mt-2 animate-pulse"></div>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <p className="text-sm font-medium text-purple-800">Sono</p>
              <div className="h-8 bg-purple-200 rounded mt-2 animate-pulse"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
