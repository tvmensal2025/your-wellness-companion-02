// Adaptador para normalizar dados de cardápio entre diferentes formatos
import { debugMealPlan, logRestrictionDebug } from './debug-helper';

export interface StandardMeal {
  title: string;
  description: string;
  ingredients: string[];
  practicalSuggestion?: string;
  macros: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
    fiber?: number;
  };
}

export interface StandardDayPlan {
  day: number;
  meals: {
    breakfast?: StandardMeal;
    lunch?: StandardMeal;
    snack?: StandardMeal;
    dinner?: StandardMeal;
    supper?: StandardMeal;
  };
  dailyTotals?: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
    fiber?: number;
  };
}

// Adapta dados da Edge Function GPT-4 para formato padrão com verificação de restrições
export function adaptGPT4ToStandard(gpt4Data: any): StandardDayPlan[] {
  console.log('🤖 Adaptando dados do GPT-4:', gpt4Data);
  
  if (!gpt4Data) {
    console.warn('⚠️ Dados GPT-4 inválidos para adaptação');
    return [];
  }

  // Verificar se há metadados com restrições
  if (gpt4Data.metadata?.restricoes_aplicadas?.length > 0) {
    console.log('🔍 Verificando restrições nos dados do GPT-4:', gpt4Data.metadata.restricoes_aplicadas);
    logRestrictionDebug(gpt4Data.metadata.restricoes_aplicadas, 'GPT-4 Adapter');
  }

  // Detectar estrutura dos dados GPT-4
  let cardapio;
  
  if (gpt4Data.cardapio?.cardapio) {
    // Estrutura: data.cardapio.cardapio
    console.log('📊 Estrutura GPT-4 detectada: data.cardapio.cardapio');
    cardapio = gpt4Data.cardapio.cardapio;
  } else if (gpt4Data.cardapio) {
    // Estrutura: data.cardapio
    console.log('📊 Estrutura GPT-4 detectada: data.cardapio');
    cardapio = gpt4Data.cardapio;
  } else if (gpt4Data.dia1) {
    // Estrutura: data.dia1, data.dia2 (dados diretos)
    console.log('📊 Estrutura GPT-4 detectada: dados diretos');
    cardapio = gpt4Data;
  } else {
    console.warn('⚠️ Estrutura GPT-4 não reconhecida:', Object.keys(gpt4Data));
    return [];
  }

  const adaptedDays: StandardDayPlan[] = [];

  // Processar cada dia
  for (let dayNum = 1; dayNum <= 7; dayNum++) {
    const diaKey = `dia${dayNum}`;
    const diaData = cardapio[diaKey];
    
    if (!diaData) continue;

    const adaptedDay: StandardDayPlan = {
      day: dayNum,
      meals: {}
    };

    // Mapear refeições do GPT-4 para formato padrão
    const mealMappings = {
      'cafe_manha': 'breakfast',
      'café da manhã': 'breakfast',
      'almoco': 'lunch', 
      'almoço': 'lunch',
      'cafe_tarde': 'snack',
      'lanche': 'snack',
      'jantar': 'dinner',
      'ceia': 'supper'
    };

    Object.entries(mealMappings).forEach(([gpt4Key, standardKey]) => {
      const mealData = diaData[gpt4Key];
      if (mealData) {
        (adaptedDay.meals as any)[standardKey] = adaptGPT4Meal(mealData);
      }
    });

    // Adaptar totais do dia
    if (diaData.totais_do_dia) {
      adaptedDay.dailyTotals = {
        calories: diaData.totais_do_dia.calorias || 0,
        protein: diaData.totais_do_dia.proteinas || 0,
        carbs: diaData.totais_do_dia.carboidratos || 0,
        fat: diaData.totais_do_dia.gorduras || 0,
        fiber: diaData.totais_do_dia.fibras || 0
      };
    }

    adaptedDays.push(adaptedDay);
  }

  // Verificação final de restrições no cardápio adaptado
  if (gpt4Data.metadata?.restricoes_aplicadas?.length > 0 && adaptedDays.length > 0) {
    console.log('🔍 Verificação final de restrições no cardápio adaptado');
    const validation = debugMealPlan(adaptedDays, gpt4Data.metadata.restricoes_aplicadas);
    if (!validation.isValid) {
      console.error('❌ Cardápio adaptado violou restrições:', validation.violations);
      // Retornar vazio para forçar nova geração
      return [];
    } else {
      console.log('✅ Cardápio adaptado respeitou todas as restrições!');
    }
  }

  console.log('✅ Dados GPT-4 adaptados com sucesso!', adaptedDays.length, 'dias encontrados');
  console.log('🔄 Dados adaptados para visualização:', adaptedDays);
  return adaptedDays;
}

// Adapta dados da Edge Function Ultra Safe para formato padrão
export function adaptUltraSafeToStandard(edgeFunctionData: any): StandardDayPlan[] {
  console.log('🔄 Adaptando dados da Edge Function:', edgeFunctionData);
  
  if (!edgeFunctionData) {
    console.warn('⚠️ Dados inválidos para adaptação');
    return [];
  }

  // Detectar estrutura dos dados
  let cardapio;
  
  if (edgeFunctionData.cardapio?.cardapio) {
    // Estrutura: data.cardapio.cardapio
    console.log('📊 Estrutura detectada: data.cardapio.cardapio');
    cardapio = edgeFunctionData.cardapio.cardapio;
  } else if (edgeFunctionData.cardapio) {
    // Estrutura: data.cardapio
    console.log('📊 Estrutura detectada: data.cardapio');
    cardapio = edgeFunctionData.cardapio;
  } else if (edgeFunctionData.dia1) {
    // Estrutura: data.dia1, data.dia2 (dados diretos)
    console.log('📊 Estrutura detectada: dados diretos');
    cardapio = edgeFunctionData;
  } else {
    console.warn('⚠️ Estrutura de dados não reconhecida:', Object.keys(edgeFunctionData));
    return [];
  }
  const adaptedDays: StandardDayPlan[] = [];

  // Processar cada dia
  for (let dayNum = 1; dayNum <= 7; dayNum++) {
    const diaKey = `dia${dayNum}`;
    const diaData = cardapio[diaKey];
    
    if (!diaData) continue;

    const adaptedDay: StandardDayPlan = {
      day: dayNum,
      meals: {}
    };

    // Adaptar cada refeição
    const mealMappings = {
      'cafe_manha': 'breakfast',
      'almoco': 'lunch', 
      'lanche': 'snack',
      'jantar': 'dinner',
      'ceia': 'supper'
    };

    Object.entries(mealMappings).forEach(([edgeKey, standardKey]) => {
      const mealData = diaData[edgeKey];
      if (mealData) {
        (adaptedDay.meals as any)[standardKey] = adaptMeal(mealData);
      }
    });

    // Adaptar totais do dia
    if (diaData.totais_do_dia) {
      adaptedDay.dailyTotals = {
        calories: diaData.totais_do_dia.calorias || 0,
        protein: diaData.totais_do_dia.proteinas || 0,
        carbs: diaData.totais_do_dia.carboidratos || 0,
        fat: diaData.totais_do_dia.gorduras || 0,
        fiber: diaData.totais_do_dia.fibras || 0
      };
    }

    adaptedDays.push(adaptedDay);
  }

  console.log('✅ Dados adaptados:', adaptedDays);
  return adaptedDays;
}

// Adapta uma refeição individual do GPT-4
function adaptGPT4Meal(mealData: any): StandardMeal {
  const ingredients = Array.isArray(mealData.ingredientes) 
    ? mealData.ingredientes.map((ing: any) => 
        typeof ing === 'string' ? ing : `${ing.nome} (${ing.quantidade})`
      )
    : [];

  // Calcular macros da refeição
  const macros = {
    calories: mealData.calorias_totais || 0,
    protein: mealData.proteinas_totais || 0,
    carbs: mealData.carboidratos_totais || 0,
    fat: mealData.gorduras_totais || 0,
    fiber: mealData.fibras_totais || 0
  };

  return {
    title: mealData.nome || 'Refeição',
    description: mealData.preparo || '1. Organizar todos os ingredientes na bancada de trabalho\n2. Verificar se todos os utensílios estão limpos\n3. Seguir as instruções de preparo específicas\n4. Temperar adequadamente com sal e especiarias\n5. Verificar o ponto de cozimento dos alimentos\n6. Servir na temperatura adequada para cada alimento\n7. Consumir com moderação e atenção\n8. Acompanhar com bebidas adequadas\n9. Limpar a área de preparo após o consumo\n10. Guardar sobras adequadamente\n11. Verificar se todos os nutrientes estão presentes\n12. Aproveitar a refeição com calma e atenção',
    ingredients,
    practicalSuggestion: mealData.tempo_preparo || '',
    macros
  };
}

// Adapta uma refeição individual
function adaptMeal(mealData: any): StandardMeal {
  const ingredients = Array.isArray(mealData.ingredientes) 
    ? mealData.ingredientes.map((ing: any) => 
        typeof ing === 'string' ? ing : ing.nome || 'Ingrediente'
      )
    : [];

  // Calcular macros da refeição
  const macros = {
    calories: 0,
    protein: 0,
    carbs: 0,
    fat: 0,
    fiber: 0
  };

  if (Array.isArray(mealData.ingredientes)) {
    mealData.ingredientes.forEach((ing: any) => {
      if (typeof ing === 'object') {
        macros.calories += ing.calorias || 0;
        macros.protein += ing.proteinas || 0;
        macros.carbs += ing.carboidratos || 0;
        macros.fat += ing.gorduras || 0;
        macros.fiber += ing.fibras || 0;
      }
    });
  }

  return {
    title: mealData.nome || 'Refeição',
    description: mealData.preparo || '1. Organizar todos os ingredientes na bancada de trabalho\n2. Verificar se todos os utensílios estão limpos\n3. Seguir as instruções de preparo específicas\n4. Temperar adequadamente com sal e especiarias\n5. Verificar o ponto de cozimento dos alimentos\n6. Servir na temperatura adequada para cada alimento\n7. Consumir com moderação e atenção\n8. Acompanhar com bebidas adequadas\n9. Limpar a área de preparo após o consumo\n10. Guardar sobras adequadamente\n11. Verificar se todos os nutrientes estão presentes\n12. Aproveitar a refeição com calma e atenção',
    ingredients,
    practicalSuggestion: mealData.dica_nutricional || mealData.tempo_preparo || '',
    macros
  };
}

// Adapta dados salvos do histórico
export function adaptHistoryData(historyItem: any): StandardDayPlan[] {
  console.log('📚 Adaptando dados do histórico:', historyItem);
  
  const mealPlanData = historyItem.meal_plan_data;
  
  if (!mealPlanData) {
    console.warn('⚠️ Nenhum dado de meal_plan_data encontrado');
    return [];
  }

  // Se já está no formato padrão
  if (Array.isArray(mealPlanData) && mealPlanData[0]?.day) {
    console.log('📋 Dados já estão no formato padrão');
    return mealPlanData;
  }
  
  if (Array.isArray(mealPlanData.plan) && mealPlanData.plan[0]?.day) {
    console.log('📋 Dados no formato padrão dentro de plan');
    return mealPlanData.plan;
  }

  // Se é dados da Edge Function GPT-4
  if (mealPlanData.plan?.cardapio) {
    console.log('🤖 Adaptando dados GPT-4 do histórico');
    return adaptGPT4ToStandard(mealPlanData.plan);
  }

  // Se é dados da Edge Function Ultra Safe
  if (mealPlanData.cardapio) {
    console.log('🔧 Adaptando dados Ultra Safe do histórico');
    return adaptUltraSafeToStandard(mealPlanData);
  }

  console.warn('⚠️ Formato de dados do histórico não reconhecido:', Object.keys(mealPlanData));
  return [];
}

// Adapta dados do Mealie para formato padrão com verificação de restrições
export function adaptMealieToStandard(mealieData: any): StandardDayPlan[] {
  console.log('🍽️ Adaptando dados do Mealie:', mealieData);
  
  // Verificar se os dados estão na estrutura correta
  if (mealieData?.cardapio && Array.isArray(mealieData.cardapio)) {
    console.log('📊 Estrutura detectada: data.cardapio (array)');
    mealieData = mealieData.cardapio;
  } else if (mealieData?.cardapio && !Array.isArray(mealieData.cardapio)) {
    console.log('📊 Estrutura detectada: data.cardapio (objeto único)');
    mealieData = [mealieData.cardapio];
  } else if (Array.isArray(mealieData)) {
    console.log('📊 Estrutura detectada: array direto');
  } else {
    console.warn('⚠️ Estrutura de dados do Mealie não reconhecida:', mealieData);
    return [];
  }

  // Debug das restrições se existirem
  if (mealieData.length > 0) {
    const firstDay = mealieData[0];
    if (firstDay?.restrictions) {
      logRestrictionDebug(firstDay.restrictions, 'Mealie');
      const validation = debugMealPlan(mealieData, firstDay.restrictions);
      if (!validation.isValid) {
        console.error('❌ Mealie violou restrições:', validation.violations);
        return [];
      }
    }
  }

  const adaptedDays: StandardDayPlan[] = [];

  mealieData.forEach((dayData: any) => {
    if (!dayData || !dayData.meals || !Array.isArray(dayData.meals)) {
      console.warn('⚠️ Dia sem refeições válidas:', dayData);
      return;
    }

    // Verificar apenas as refeições que foram realmente solicitadas
    const dayMealTypes = dayData.meals.map((m: any) => m.meal_type);
    console.log(`📋 Dia ${dayData.day} tem refeições:`, dayMealTypes);
    
    // NÃO adicionar refeições padrão - respeitar exatamente o que foi gerado
    // O usuário selecionou apenas as refeições que queria
    console.log(`✅ Respeitando seleção do usuário: ${dayMealTypes.length} refeições`);

    const adaptedDay: StandardDayPlan = {
      day: dayData.day || 1,
      meals: {}
    };

    // Mapear refeições do Mealie para formato padrão
    dayData.meals.forEach((meal: any) => {
      const mealType = meal.meal_type;
      
      // Mapear tipos de refeição para formato padrão
      let standardKey: keyof StandardDayPlan['meals'];
      
      switch (mealType) {
        case 'café da manhã':
        case 'cafe da manha':
          standardKey = 'breakfast';
          break;
        case 'almoço':
        case 'almoco':
          standardKey = 'lunch';
          break;
        case 'lanche':
        case 'café da tarde':
        case 'cafe da tarde':
          standardKey = 'snack';
          break;
        case 'jantar':
          standardKey = 'dinner';
          break;
        case 'ceia':
          standardKey = 'supper';
          break;
        default:
          console.warn(`⚠️ Tipo de refeição desconhecido: ${mealType}`);
          return; // Pular refeições desconhecidas
      }
      
      // Gerar instruções de preparo ULTRA DETALHADAS baseadas no nome da receita
      const gerarInstrucoesPreparo = (nome: string, tipo: string) => {
        const nomeLower = nome.toLowerCase();
        
        if (nomeLower.includes('aveia') || nomeLower.includes('oat')) {
          return '1. Organizar todos os ingredientes: aveia, leite, banana, mel, canela\n2. Medir 45g de aveia e colocar em uma panela\n3. Adicionar 150ml de leite desnatado à panela\n4. Aquecer em fogo médio até o leite quase ferver\n5. Reduzir o fogo para baixo e adicionar a aveia\n6. Mexer constantemente por 4-6 minutos até engrossar\n7. Cortar a banana em rodelas de 1cm\n8. Adicionar a banana e 5g de mel à panela\n9. Misturar suavemente para não amassar a banana\n10. Polvilhar 1g de canela em pó por cima\n11. Cozinhar por mais 1-2 minutos para apurar o sabor\n12. Transferir para uma tigela e servir quente imediatamente';
        }
        
        if (nomeLower.includes('frango') || nomeLower.includes('chicken')) {
          return '1. Organizar todos os ingredientes: frango, sal, pimenta, ervas, azeite\n2. Lavar o frango em água corrente e secar com papel toalha\n3. Temperar o frango com sal, pimenta-do-reino, alho picado e ervas\n4. Deixar marinar por 15-20 minutos na geladeira\n5. Retirar o frango da geladeira 10 minutos antes de cozinhar\n6. Aquecer uma frigideira antiaderente em fogo médio-alto\n7. Adicionar 1 colher de sopa de azeite e aguardar esquentar\n8. Colocar o frango na frigideira e grelhar por 6-8 minutos de cada lado\n9. Verificar se está cozido: temperatura interna deve ser 74°C\n10. Deixar descansar por 5-7 minutos antes de cortar\n11. Cortar em fatias diagonais para melhor apresentação\n12. Servir quente com molho ou acompanhamentos';
        }
        
        if (nomeLower.includes('iogurte') || nomeLower.includes('yogurt')) {
          return '1. Organizar todos os ingredientes: iogurte, granola, frutas (opcional)\n2. Verificar se o iogurte está na temperatura adequada\n3. Medir a porção de iogurte desejada (aproximadamente 150g)\n4. Colocar o iogurte em uma tigela ou copo\n5. Adicionar granola por cima (aproximadamente 30g)\n6. Opcional: adicionar frutas frescas picadas\n7. Misturar suavemente se desejar\n8. Polvilhar canela ou mel a gosto\n9. Servir imediatamente para manter a crocância da granola\n10. Consumir em até 30 minutos para melhor sabor\n11. Guardar sobras na geladeira por até 2 dias\n12. Acompanhar com água ou chá para hidratação';
        }
        
        if (nomeLower.includes('overnight') || nomeLower.includes('chia')) {
          return '1. Organizar todos os ingredientes: aveia, chia, leite, frutas, mel\n2. Medir 50g de aveia e colocar em um pote com tampa\n3. Adicionar 1 colher de sopa de sementes de chia\n4. Adicionar 200ml de leite (pode ser vegetal)\n5. Adicionar 1 colher de chá de mel ou adoçante\n6. Misturar bem todos os ingredientes\n7. Fechar o pote e deixar na geladeira por 8-12 horas\n8. Na manhã seguinte, retirar da geladeira\n9. Adicionar frutas frescas picadas por cima\n10. Misturar suavemente para distribuir as frutas\n11. Servir frio ou aquecer por 30 segundos no microondas\n12. Consumir imediatamente para melhor textura';
        }
        
        // Instruções padrão baseadas no tipo de refeição
        switch (tipo) {
          case 'café da manhã':
          case 'cafe da manha':
            return '1. Organizar todos os ingredientes na bancada de trabalho\n2. Verificar se todos os utensílios estão limpos e disponíveis\n3. Preparar conforme receita específica de cada ingrediente\n4. Aquecer os alimentos que precisam ser servidos quentes\n5. Montar o prato de forma atrativa e organizada\n6. Acompanhar com café, chá ou suco natural\n7. Consumir em até 30 minutos para manter a qualidade\n8. Guardar sobras adequadamente na geladeira\n9. Limpar a bancada após o preparo\n10. Verificar se todos os ingredientes foram utilizados corretamente';
          
          case 'almoço':
          case 'almoco':
            return '1. Organizar todos os ingredientes por categoria: proteínas, carboidratos, vegetais\n2. Preparar os ingredientes principais em ordem de cozimento\n3. Cozinhar primeiro a proteína (carne, frango, peixe, etc.)\n4. Em seguida, preparar o carboidrato (arroz, batata, etc.)\n5. Por último, preparar os vegetais para manter a frescura\n6. Temperar adequadamente cada componente\n7. Verificar o ponto de cozimento de cada item\n8. Montar o prato de forma atrativa e balanceada\n9. Servir quente e com apresentação adequada\n10. Acompanhar com salada ou legumes frescos\n11. Verificar se as porções estão adequadas\n12. Guardar sobras para refeições posteriores';
          
          case 'lanche':
          case 'café da tarde':
          case 'cafe da tarde':
            return '1. Organizar todos os ingredientes na bancada\n2. Verificar se os ingredientes estão frescos e adequados\n3. Preparar de forma simples e rápida para consumo imediato\n4. Medir porções adequadas para um lanche\n5. Combinar diferentes grupos alimentares\n6. Servir em porção adequada para o momento\n7. Consumir entre as refeições principais\n8. Manter hidratação com água ou chá\n9. Evitar exageros para não comprometer a próxima refeição\n10. Limpar a área de preparo após o consumo';
          
          case 'jantar':
            return '1. Organizar todos os ingredientes para uma refeição mais leve\n2. Preparar uma refeição com menos calorias que o almoço\n3. Cozinhar com pouco óleo para facilitar a digestão\n4. Incluir vegetais frescos e proteínas magras\n5. Evitar carboidratos complexos em excesso\n6. Servir em porção moderada para não sobrecarregar\n7. Consumir pelo menos 2 horas antes de dormir\n8. Incluir alimentos que facilitem o sono\n9. Evitar alimentos muito pesados ou gordurosos\n10. Acompanhar com chá ou água\n11. Verificar se a refeição está balanceada\n12. Guardar adequadamente para o dia seguinte';
          
          default:
            return '1. Organizar todos os ingredientes na bancada de trabalho\n2. Verificar se todos os utensílios estão limpos\n3. Seguir as instruções de preparo específicas\n4. Temperar adequadamente com sal e especiarias\n5. Verificar o ponto de cozimento dos alimentos\n6. Servir na temperatura adequada para cada alimento\n7. Consumir com moderação e atenção\n8. Acompanhar com bebidas adequadas\n9. Limpar a área de preparo após o consumo\n10. Guardar sobras adequadamente\n11. Verificar se todos os nutrientes estão presentes\n12. Aproveitar a refeição com calma e atenção';
        }
      };

      adaptedDay.meals[standardKey] = {
        title: meal.recipe_name || 'Refeição',
        description: gerarInstrucoesPreparo(meal.recipe_name || '', mealType),
        ingredients: meal.ingredients ? meal.ingredients.split(',').map((ing: string) => ing.trim()) : [],
        practicalSuggestion: meal.prep_time ? `Tempo de preparo: ${meal.prep_time}` : '',
        macros: {
          calories: meal.calories || 0,
          protein: meal.protein || 0,
          carbs: meal.carbs || 0,
          fat: meal.fat || 0,
          fiber: meal.fiber || 0
        }
      };
    });

    // Calcular totais do dia baseado nas refeições adaptadas
    let dailyTotals = {
      calories: 0,
      protein: 0,
      carbs: 0,
      fat: 0,
      fiber: 0
    };

    Object.values(adaptedDay.meals).forEach((meal: any) => {
      if (meal?.macros) {
        dailyTotals.calories += meal.macros.calories || 0;
        dailyTotals.protein += meal.macros.protein || 0;
        dailyTotals.carbs += meal.macros.carbs || 0;
        dailyTotals.fat += meal.macros.fat || 0;
        dailyTotals.fiber += meal.macros.fiber || 0;
      }
    });

    adaptedDay.dailyTotals = dailyTotals;
    adaptedDays.push(adaptedDay);
  });

  console.log('✅ Dados do Mealie adaptados:', adaptedDays);
  return adaptedDays;
}

// Adapta uma refeição individual do Mealie
function adaptMealieMeal(mealData: any): StandardMeal {
  const ingredients = Array.isArray(mealData.ingredientes) 
    ? mealData.ingredientes
    : [];

  const macros = {
    calories: mealData.calorias || 0,
    protein: mealData.proteinas || 0,
    carbs: mealData.carboidratos || 0,
    fat: mealData.gorduras || 0,
    fiber: mealData.fibras || 0
  };

  return {
    title: mealData.nome || 'Receita do Mealie',
    description: mealData.preparo || '1. Organizar todos os ingredientes na bancada de trabalho\n2. Verificar se todos os utensílios estão limpos\n3. Seguir as instruções de preparo específicas\n4. Temperar adequadamente com sal e especiarias\n5. Verificar o ponto de cozimento dos alimentos\n6. Servir na temperatura adequada para cada alimento\n7. Consumir com moderação e atenção\n8. Acompanhar com bebidas adequadas\n9. Limpar a área de preparo após o consumo\n10. Guardar sobras adequadamente\n11. Verificar se todos os nutrientes estão presentes\n12. Aproveitar a refeição com calma e atenção',
    ingredients,
    practicalSuggestion: mealData.tempo_preparo ? `Tempo de preparo: ${mealData.tempo_preparo} min` : '',
    macros
  };
}
