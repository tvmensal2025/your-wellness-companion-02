import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface MealieRecipe {
  id: string;
  name: string;
  description: string;
  prepTime: number;
  cookTime: number;
  totalTime: number;
  servings: number;
  ingredients: Array<{
    note: string;
    unit: string;
    food: string;
    quantity: number;
  }>;
  instructions: Array<{
    title: string;
    text: string;
  }>;
  nutrition: {
    calories: number;
    protein: number;
    carbohydrates: number;
    fat: number;
    fiber: number;
  };
  image: string;
  slug: string;
}

interface MealPlanParams {
  dias: number;
  objetivo: string;
  restricoes: string[];
  calorias: number;
  preferencias?: {
    categories?: string[];
    tags?: string[];
    excludeIngredients?: string[];
  };
}

export const useMealieIntegration = () => {
  const [loading, setLoading] = useState(false);
  const [recipes, setRecipes] = useState<MealieRecipe[]>([]);

  const mealieRequest = useCallback(async (action: string, params: any = {}) => {
    try {
      const { data, error } = await supabase.functions.invoke('mealie-integration', {
        body: { action, ...params }
      });

      if (error) throw error;

      if (!data.success) {
        throw new Error(data.error || 'Erro na requisição ao Mealie');
      }

      return data;
    } catch (error) {
      console.error('Erro na integração Mealie:', error);
      throw error;
    }
  }, []);

  const getRecipes = useCallback(async (limit = 50) => {
    setLoading(true);
    try {
      const data = await mealieRequest('get_recipes', { limit });
      const recipesList = data.data.items || [];
      setRecipes(recipesList);
      return recipesList;
    } catch (error) {
      toast.error('Erro ao carregar receitas do Mealie');
      throw error;
    } finally {
      setLoading(false);
    }
  }, [mealieRequest]);

  const searchRecipes = useCallback(async (query: string, limit = 20) => {
    setLoading(true);
    try {
      const data = await mealieRequest('search_recipes', { query, limit });
      const recipesList = data.data.items || [];
      setRecipes(recipesList);
      return recipesList;
    } catch (error) {
      toast.error('Erro ao buscar receitas');
      throw error;
    } finally {
      setLoading(false);
    }
  }, [mealieRequest]);

  const getRecipe = useCallback(async (recipeId: string) => {
    try {
      const data = await mealieRequest('get_recipe', { recipeId });
      return data.data;
    } catch (error) {
      toast.error('Erro ao carregar receita');
      throw error;
    }
  }, [mealieRequest]);

  const generateMealPlan = useCallback(async (params: MealPlanParams) => {
    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      const data = await mealieRequest('generate_sofia_meal_plan', {
        ...params,
        userId: user?.id
      });

      toast.success(`Cardápio de ${params.dias} dias gerado com receitas do Mealie!`);
      return data.mealPlan;
    } catch (error) {
      toast.error('Erro ao gerar cardápio com Mealie');
      throw error;
    } finally {
      setLoading(false);
    }
  }, [mealieRequest]);

  const createMealPlan = useCallback(async (startDate: string, endDate: string) => {
    try {
      const data = await mealieRequest('create_meal_plan', {
        startDate,
        endDate
      });
      
      toast.success('Plano de refeições criado no Mealie!');
      return data.data;
    } catch (error) {
      toast.error('Erro ao criar plano no Mealie');
      throw error;
    }
  }, [mealieRequest]);

  const getMealPlans = useCallback(async () => {
    try {
      const data = await mealieRequest('get_meal_plans');
      return data.data.items || [];
    } catch (error) {
      toast.error('Erro ao carregar planos de refeição');
      throw error;
    }
  }, [mealieRequest]);

  return {
    loading,
    recipes,
    getRecipes,
    searchRecipes,
    getRecipe,
    generateMealPlan,
    createMealPlan,
    getMealPlans,
    mealieRequest
  };
};