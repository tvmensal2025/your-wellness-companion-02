import type { VisitData, ReportJSON } from "./types";
import { GPTAgent } from "@/lib/openai-client";

const pickModel = () => ({
  primary: 'gpt-4o',
  fallback: 'gpt-4o-mini',
  legacy: 'gpt-4o',
});

const SYSTEM_PT = `
Você é o Dr. Vital (IA) do Instituto dos Sonhos. Fale em português do Brasil,
linguagem simples e respeitosa, SEM diagnóstico ou prescrição.
Explique cada bloco de exames para leigos. Mantenha estrutura sênior:
após cada tabela, inclua "O que isso significa?", "Dr. Vital sugere (em casa)" e
"Converse com o médico se...". Nunca invente dados; assuma "—" se faltarem.
`;

export async function generateMedicalReport(input: VisitData): Promise<ReportJSON> {
  const { primary, fallback, legacy } = pickModel();

  const userTask = buildTask(input); // monta texto com instruções e dados

  const agent = new GPTAgent(primary, 4000, 0.2);
  agent.setSystemPrompt(SYSTEM_PT);

  let used = primary;
  let notice = "";
  let content = "";

  try {
    const res = await agent.sendMessage(userTask);
    content = res?.content ?? "";
  } catch (e) {
    try {
      used = fallback;
      agent.setParameters(fallback, 4000, 0.25);
      const res2 = await agent.sendMessage(userTask);
      content = res2?.content ?? "";
      notice = `Fallback primário→${fallback}`;
    } catch (e2) {
      used = legacy;
      agent.setParameters(legacy, 3500, 0.3);
      const res3 = await agent.sendMessage(userTask);
      content = res3?.content ?? "";
      notice = `Fallback primário/seg→${legacy}`;
    }
  }

  // Parsing robusto de JSON
  let json: ReportJSON;
  try { json = JSON.parse(content || "{}"); }
  catch {
    const start = content.indexOf('{');
    const end = content.lastIndexOf('}');
    if (start >= 0 && end > start) {
      try { json = JSON.parse(content.slice(start, end + 1)); }
      catch { json = {} as any; }
    } else {
      json = {} as any;
    }
  }

  json.model_used = used;
  if (notice) json.model_fallback_notice = notice;

  if (!json.html) json.html = renderHTML(input, json);
  return json;
}

function buildTask(input: VisitData) {
  // Anexe os exames em JSON puro para o modelo usar sem ambiguidade
  return `
Gere um ReportJSON completo (conforme schema) + HTML final elegante, imprimível.
Use as cores: roxo #5A3DF0 (brand), laranja #FF7A18 (accent), texto #1E2233, borda #E7EAF3.
Fonte >=16px, contraste alto, layout aberto (sem accordions).

DADOS:
${JSON.stringify(input, null, 2)}

INSTRUÇÕES DE CONTEÚDO:
- "Resumo em 1 minuto" com 4–6 bullets.
- Seções esperadas (crie apenas as aplicáveis): 
  1) Coração/Colesterol (LDL/HDL),
  2) Açúcar no sangue (Glicose, HbA1c, Insulina, HOMA‑IR),
  3) Rins (Ureia/Creatinina),
  4) Fígado (ALT/TGP, AST/TGO),
  5) Tireoide (ex.: TSH, T4L),
  6) Vitaminas e Estoques de Ferro (B12, Ferritina, Ferro sérico),
  7) Eletrólitos (Sódio, Potássio, Cálcio, Magnésio),
  8) Fezes (Parasitológico, Sangue Oculto).
- Em cada seção, gere: tabela (Exame|Resultado|Referência|Status|Significado curto)
  + blocos: "O que isso significa?", "Dr. Vital sugere (em casa)", "Converse com o médico se..."
- Se houver exames anteriores, exiba DELTAS (antes→agora, Δ) dentro da tabela.
- Acrescente "Plano simples — próximos 7 dias" e "Glossário".
- Feche com um disclaimer claro (documento educativo, sem substituir consulta).

INSTRUÇÕES DO HTML:
- Cabeçalho com logo ${input.logoUrl} e KPIs (nome, idade, sexo, datas, HbA1c, HOMA‑IR).
- Bloco "Informações do Paciente" em grid com cartões: Nome, Idade, Sexo, Data de Coleta, (opcional) Laboratório e Especialista.
- Bloco de apresentação do Dr. Vital com avatar/emoji e mensagem curta.
- Cada seção em <section> com título grande e ícone (emoji) e selo de status (ex.: ✅, ⚠️, 🔴).
- Tabelas com linhas alternadas claras, colunas: Exame | Resultado | Referência | Status | Interpretação.
- Em seguida os 3 blocos explicativos em caixas suaves.
- Botão fixo no topo direito: "Imprimir / Salvar PDF" (onclick="window.print()").
- CSS com @media print (ocultar botão, remover sombras, cores sólidas) e design responsivo.
- Não use frameworks, apenas CSS inline no <style>.

RETORNE APENAS ReportJSON válido no message.content.
`;
}

/** Render local fallback (idêntico ao estilo que exigimos do modelo) */
function renderHTML(input: VisitData, r: ReportJSON) {
  const now = new Date().toLocaleString("pt-BR");
  const kpi = `
  <div class="kpis">
    <div class="kpi"><div class="l">Paciente</div><div class="v">${input.patient.name}</div><div class="s">${input.patient.age} anos • ${input.patient.sex}</div></div>
    <div class="kpi"><div class="l">Nascimento</div><div class="v">${input.patient.birth}</div><div class="s">Coleta: ${input.visit.date}</div></div>
    <div class="kpi"><div class="l">Açúcar do sangue</div><div class="v">${peek(r,"Açúcar no sangue","Glicose")}</div><div class="s">HbA1c ${peek(r,"Açúcar no sangue","HbA1c")}</div></div>
    <div class="kpi"><div class="l">HOMA‑IR</div><div class="v">${peek(r,"Açúcar no sangue","HOMA‑IR")}</div><div class="s">Estimativa</div></div>
  </div>`.trim();

  const sections = (r.sections || []).map(sec => sectionHTML(sec)).join("\n");

  return `<!doctype html>
<html lang="pt-BR"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Relatório Clínico Integrativo — Instituto dos Sonhos</title>
<style>
:root{ --brand:#5A3DF0; --accent:#FF7A18; --ink:#1E2233; --muted:#5E6A81; --bg:#F6F7FC; --card:#FFFFFF; --line:#E7EAF3; --ok:#167C3B; --warn:#B26A00; --bad:#B11C1C; }
*{box-sizing:border-box} body{margin:0;background:var(--bg);color:var(--ink);font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial;font-size:16px;line-height:1.65}
.page{max-width:980px;margin:0 auto;padding:20px}
.header{position:relative;border-radius:18px;overflow:hidden;border:1px solid var(--line);box-shadow:0 10px 30px rgba(0,0,0,.04)}
.header .bar{background:linear-gradient(135deg,#5A3DF0,#2ED4FF);padding:24px 18px;color:#fff;display:flex;gap:12px;align-items:center}
.header img{height:56px;border-radius:8px;background:#fff;padding:6px}
.h1{margin:0;font-size:28px;font-weight:800}
.sub{opacity:.95}
.kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;padding:12px;background:var(--card)}
.kpi{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:10px}
.kpi .l{font-size:13px;color:var(--muted)} .kpi .v{font-size:18px;font-weight:800} .kpi .s{font-size:12px;color:var(--muted)}
.btn-print{position:sticky;top:10px;float:right;background:var(--brand);color:#fff;border:none;border-radius:10px;padding:10px 14px;cursor:pointer}
section.block{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:16px;margin-top:14px}
.stitle{margin:0 0 8px 0;font-size:22px}
.patient-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}
.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:12px}
.doctor{display:flex;gap:14px;align-items:center}
.doctor .avatar{font-size:42px;line-height:1}
.badge{display:inline-block;padding:4px 10px;border-radius:999px;border:1px solid var(--line);font-size:13px}
.badge.ok{background:#E9F7EF;color:var(--ok)} .badge.warn{background:#FFF6E5;color:var(--warn)} .badge.bad{background:#FDECEC;color:var(--bad)}
table{width:100%;border-collapse:collapse} th,td{padding:10px;border-bottom:1px dashed var(--line);text-align:left}
th{color:var(--muted)}
.explain{border:1px solid var(--line);background:#FCFEFF;border-radius:12px;padding:12px;margin-top:10px}
.explain h4{margin:0 0 6px 0}
@media (max-width:820px){ .kpis{grid-template-columns:repeat(2,1fr)} .patient-grid{grid-template-columns:repeat(2,1fr)} }
@media print{ .btn-print{display:none} body{background:#fff} .page{padding:0} .header{box-shadow:none} }
</style>
</head>
<body>
<div class="page">
  <button class="btn-print" onclick="window.print()">Imprimir / Salvar PDF</button>
  <div class="header">
    <div class="bar">
      <img src="${input.logoUrl}" alt="Instituto dos Sonhos">
      <div>
        <h1 class="h1">Relatório Clínico Integrativo</h1>
        <div class="sub">Gerado por Sof.ia & Dr. Vital • ${now}</div>
      </div>
    </div>
    <div class="kpis">
      <div class="kpi"><div class="l">Paciente</div><div class="v">${input.patient.name}</div><div class="s">${input.patient.age} anos • ${input.patient.sex}</div></div>
      <div class="kpi"><div class="l">Nascimento</div><div class="v">${input.patient.birth}</div><div class="s">Coleta: ${input.visit.date}</div></div>
      <div class="kpi"><div class="l">Açúcar do sangue</div><div class="v">${peek(r,"Açúcar no sangue","Glicose")}</div><div class="s">HbA1c ${peek(r,"Açúcar no sangue","HbA1c")}</div></div>
      <div class="kpi"><div class="l">HOMA‑IR</div><div class="v">${peek(r,"Açúcar no sangue","HOMA‑IR")}</div><div class="s">Estimativa</div></div>
    </div>
  </div>

  <section class="block">
    <h2 class="stitle">👤 Informações do Paciente</h2>
    <div class="patient-grid">
      <div class="card"><strong>Nome:</strong><div>${input.patient.name}</div></div>
      <div class="card"><strong>Idade:</strong><div>${input.patient.age} anos</div></div>
      <div class="card"><strong>Sexo:</strong><div>${input.patient.sex}</div></div>
      <div class="card"><strong>Data dos Exames:</strong><div>${input.visit.date}</div></div>
      <div class="card"><strong>Nascimento:</strong><div>${input.patient.birth}</div></div>
      <div class="card"><strong>Relatório:</strong><div>${now.split(" ")[0]}</div></div>
    </div>
  </section>

  <section class="block doctor">
    <div class="avatar">👨‍⚕️</div>
    <div>
      <h2 class="stitle" style="margin:0">Olá! Sou o Dr. Vital 👋</h2>
      <p>Analisei seus exames com uma visão integrativa e preventiva. Vou explicar cada resultado de forma clara e mostrar como eles se conectam para compor um quadro completo da sua saúde.</p>
      <p><strong>Principais achados:</strong> veja o resumo abaixo e os detalhes nas seções.</p>
    </div>
  </section>

  <section class="block"><h2 class="stitle">Resumo em 1 minuto</h2><ul>${(r.summary_bullets || []).map(li=>`<li>${li}</li>`).join("")}</ul></section>
  ${sections}
  <section class="block"><h2 class="stitle">Plano simples — próximos 7 dias</h2><ul>${(r.plan_next7days || []).map(li=>`<li>${li}</li>`).join("")}</ul></section>
  <section class="block"><h2 class="stitle">Glossário</h2><ul>${(r.glossary || []).map(g=>`<li><strong>${g.term}:</strong> ${g.plain}</li>`).join("")}</ul></section>
  <p class="sub">${r.disclaimer}</p>
</div>
</body></html>`;
}

function sectionHTML(sec: ReportJSON["sections"][number]) {
  const rows = (sec.table || []).map(t => `
  <tr>
    <td><strong>${t.exam}</strong></td>
    <td><strong>${t.value}</strong></td>
    <td>${t.reference || "—"}</td>
    <td>${statusChip(t.status)}</td>
    <td>${t.meaning || ""}</td>
  </tr>`).join("");

  // Status geral da seção (baseado nos itens da tabela)
  const allStatuses = (sec.table || []).map(t => (t.status || "").toLowerCase());
  const hasBad = allStatuses.some(s => s.includes("alto"));
  const hasWarn = allStatuses.some(s => s.includes("atenção"));
  const badgeClass = hasBad ? "bad" : hasWarn ? "warn" : "ok";
  const badgeText = hasBad ? "🔴 Atenção imediata" : hasWarn ? "⚠️ Atenção" : "✅ Dentro do esperado";

  return `
<section class="block">
  <div style="display:flex;align-items:center;justify-content:space-between;gap:12px">
    <h2 class="stitle" style="margin:0">${sec.title}</h2>
    <span class="badge ${badgeClass}">${badgeText}</span>
  </div>
  <div style="display:grid;grid-template-columns:1.4fr 1fr;gap:16px;margin-top:8px">
    <div>
      <table>
        <thead><tr><th>Exame</th><th>Resultado</th><th>Referência</th><th>Status</th><th>Interpretação</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <div style="font-size:12px;color:#5E6A81;margin-top:6px">Notas: quando disponível, apresentamos referências BR/EUA.</div>
    </div>
    <div>
      <div class="explain"><h4>O que isso significa?</h4><p>${sec.explain_simple}</p></div>
      <div class="explain"><h4>Dr. Vital sugere (em casa)</h4><ul>${(sec.vital_suggests||[]).map(x=>`<li>${x}</li>`).join("")}</ul></div>
      ${sec.talk_to_doctor?.length ? `<div class="explain"><h4>Converse com o médico se…</h4><ul>${sec.talk_to_doctor.map(x=>`<li>${x}</li>`).join("")}</ul></div>` : ""}
    </div>
  </div>
</section>`;
}

function statusChip(s?: string) {
  if (!s) return "—";
  const map: any = { bom: "🟢 Bom", normal:"🟢 Normal", "atenção":"🟡 Atenção", alto:"🔴 Alto" };
  return map[s] || s;
}

// Util: puxa valores de tabela por nome para KPIs
function peek(r: ReportJSON, secTitle: string, exam: string) {
  const s = r.sections?.find(s => s.title.toLowerCase().includes(secTitle.toLowerCase()));
  const t = s?.table.find(t => t.exam.toLowerCase().includes(exam.toLowerCase()));
  return t?.value ?? "—";
}


