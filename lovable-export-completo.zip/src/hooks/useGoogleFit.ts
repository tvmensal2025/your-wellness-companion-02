import { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface GoogleFitData {
  steps: number;
  calories: number;
  activeMinutes: number;
  sleep: number;
  heartRate: {
    min: number;
    avg: number;
    max: number;
  };
}

export const useGoogleFit = () => {
  const [isConnected, setIsConnected] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [fitData, setFitData] = useState<GoogleFitData | null>(null);
  const { toast } = useToast();

  // Verificar se já está conectado
  useEffect(() => {
    checkConnectionStatus();
  }, []);

  const checkConnectionStatus = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('*')
          .eq('user_id', user.id)
          .single();
        
        // Como o campo não existe ainda, sempre false
        setIsConnected(false);
      }
    } catch (error) {
      console.error('Erro ao verificar status:', error);
    }
  };

  const connectGoogleFit = async () => {
    setIsLoading(true);
    try {
      // Chamar Edge Function para conectar Google Fit
      const { data, error } = await supabase.functions.invoke('google-fit-token', {
        body: { action: 'connect' }
      });

      if (error) {
        throw error;
      }

      if (data?.authUrl) {
        // Redirecionar para autorização do Google Fit
        window.location.href = data.authUrl;
      } else {
        toast({
          title: "Erro",
          description: "Não foi possível conectar ao Google Fit",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Erro ao conectar Google Fit:', error);
      toast({
        title: "Erro",
        description: "Erro ao conectar com Google Fit",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const disconnectGoogleFit = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        // TODO: Implementar desconexão quando o campo existir
        console.log('Desconectando Google Fit para usuário:', user.id);
        
        setIsConnected(false);
        toast({
          title: "Desconectado",
          description: "Google Fit desconectado com sucesso"
        });
      }
    } catch (error) {
      console.error('Erro ao desconectar:', error);
      toast({
        title: "Erro",
        description: "Erro ao desconectar Google Fit",
        variant: "destructive"
      });
    }
  };

  const syncGoogleFitData = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('google-fit-sync', {
        body: { action: 'sync' }
      });

      if (error) {
        throw error;
      }

      if (data?.success) {
        setFitData(data.fitData);
        toast({
          title: "Sincronizado!",
          description: "Dados do Google Fit atualizados"
        });
      }
    } catch (error) {
      console.error('Erro ao sincronizar:', error);
      toast({
        title: "Erro",
        description: "Erro ao sincronizar dados do Google Fit",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return {
    isConnected,
    isLoading,
    fitData,
    connectGoogleFit,
    disconnectGoogleFit,
    syncGoogleFitData,
    checkConnectionStatus
  };
};
