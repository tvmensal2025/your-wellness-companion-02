import React, { useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useGoogleFit } from '@/hooks/useGoogleFit';
import { Activity, Heart, Zap, Clock, TrendingUp, CheckCircle, XCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export const GoogleFitConnect: React.FC = () => {
  const { isConnected, isLoading, connectGoogleFit, disconnectGoogleFit, checkConnectionStatus } = useGoogleFit();
  const { toast } = useToast();

  useEffect(() => {
    // Ouvir mensagens do popup de autorização
    const handleMessage = (event: MessageEvent) => {
      if (event.data?.type === 'GOOGLE_FIT_CONNECTED') {
        if (event.data.success) {
          toast({
            title: "✅ Conectado!",
            description: "Google Fit conectado com sucesso!"
          });
          checkConnectionStatus();
        }
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [toast, checkConnectionStatus]);

  const handleConnect = async () => {
    try {
      await connectGoogleFit();
    } catch (error) {
      toast({
        title: "❌ Erro",
        description: "Erro ao conectar com Google Fit",
        variant: "destructive"
      });
    }
  };

  const handleDisconnect = async () => {
    try {
      await disconnectGoogleFit();
    } catch (error) {
      toast({
        title: "❌ Erro",
        description: "Erro ao desconectar Google Fit",
        variant: "destructive"
      });
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Activity className="h-5 w-5 text-primary" />
          Conecte o Google Fit e acompanhe sua evolução
        </CardTitle>
        <CardDescription>
          Sincronize automaticamente seus passos, calorias ativas, minutos de intensidade, 
          sono e frequência cardíaca para análises inteligentes e relatórios do Dr. Vital.
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Status da conexão */}
        <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
          <div className="flex items-center gap-2">
            {isConnected ? (
              <>
                <CheckCircle className="h-5 w-5 text-green-500" />
                <span className="font-medium">Conectado ao Google Fit</span>
                <Badge variant="secondary" className="bg-green-100 text-green-800">
                  Ativo
                </Badge>
              </>
            ) : (
              <>
                <XCircle className="h-5 w-5 text-red-500" />
                <span className="font-medium">Não conectado</span>
                <Badge variant="secondary" className="bg-red-100 text-red-800">
                  Inativo
                </Badge>
              </>
            )}
          </div>
        </div>

        {/* Dados que serão sincronizados */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
            <TrendingUp className="h-5 w-5 text-blue-600" />
            <div>
              <p className="font-medium text-sm">Passos e distância</p>
              <p className="text-xs text-muted-foreground">Contagem diária</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3 p-3 bg-red-50 rounded-lg">
            <Heart className="h-5 w-5 text-red-600" />
            <div>
              <p className="font-medium text-sm">FC min/média/máx</p>
              <p className="text-xs text-muted-foreground">Frequência cardíaca</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3 p-3 bg-yellow-50 rounded-lg">
            <Zap className="h-5 w-5 text-yellow-600" />
            <div>
              <p className="font-medium text-sm">Calorias ativas</p>
              <p className="text-xs text-muted-foreground">Queima calórica</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
            <Clock className="h-5 w-5 text-green-600" />
            <div>
              <p className="font-medium text-sm">Heart minutes e sono</p>
              <p className="text-xs text-muted-foreground">Atividade e descanso</p>
            </div>
          </div>
        </div>

        {/* Botões de ação */}
        <div className="flex flex-col sm:flex-row gap-3">
          {!isConnected ? (
            <Button 
              onClick={handleConnect} 
              disabled={isLoading}
              className="flex-1"
              size="lg"
            >
              {isLoading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                  Conectando...
                </>
              ) : (
                <>
                  <Activity className="mr-2 h-4 w-4" />
                  Conectar Google Fit
                </>
              )}
            </Button>
          ) : (
            <Button 
              onClick={handleDisconnect} 
              variant="outline"
              className="flex-1"
              size="lg"
            >
              <XCircle className="mr-2 h-4 w-4" />
              Desconectar Google Fit
            </Button>
          )}
          
          {isConnected && (
            <Button 
              variant="secondary"
              className="flex-1"
              size="lg"
            >
              <TrendingUp className="mr-2 h-4 w-4" />
              Já conectei, atualizar
            </Button>
          )}
        </div>

        {/* Nota de segurança */}
        <div className="p-3 bg-muted/30 border border-muted rounded-lg">
          <p className="text-xs text-muted-foreground text-center">
            🔒 Autorização única. Seus dados permanecem salvos com segurança no Supabase.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};
