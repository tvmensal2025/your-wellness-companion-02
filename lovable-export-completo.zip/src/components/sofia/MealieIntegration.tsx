import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, ChefHat, Clock, Users, Star } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface MealieRecipe {
  id: string;
  name: string;
  description: string;
  prepTime: number;
  cookTime: number;
  totalTime: number;
  servings: number;
  ingredients: Array<{
    note: string;
    unit: string;
    food: string;
    quantity: number;
  }>;
  instructions: Array<{
    title: string;
    text: string;
  }>;
  nutrition: {
    calories: number;
    protein: number;
    carbohydrates: number;
    fat: number;
    fiber: number;
  };
  image: string;
  slug: string;
  rating?: number;
}

interface MealieIntegrationProps {
  onRecipeSelect?: (recipe: MealieRecipe) => void;
  onMealPlanGenerate?: (mealPlan: any) => void;
}

const MealieIntegration: React.FC<MealieIntegrationProps> = ({
  onRecipeSelect,
  onMealPlanGenerate
}) => {
  const [recipes, setRecipes] = useState<MealieRecipe[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);

  useEffect(() => {
    loadRecipes();
  }, []);

  const loadRecipes = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('mealie-integration', {
        body: { action: 'get_recipes' }
      });

      if (error) throw error;

      if (data.success) {
        setRecipes(data.data.items || []);
        toast.success(`${data.data.items?.length || 0} receitas carregadas do Mealie`);
      }
    } catch (error) {
      console.error('Erro ao carregar receitas:', error);
      toast.error('Erro ao conectar com o Mealie');
    } finally {
      setLoading(false);
    }
  };

  const searchRecipes = async () => {
    if (!searchQuery.trim()) {
      loadRecipes();
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('mealie-integration', {
        body: { 
          action: 'search_recipes',
          query: searchQuery,
          limit: 20
        }
      });

      if (error) throw error;

      if (data.success) {
        setRecipes(data.data.items || []);
      }
    } catch (error) {
      console.error('Erro na busca:', error);
      toast.error('Erro ao buscar receitas');
    } finally {
      setLoading(false);
    }
  };

  const generateSofiaMealPlan = async () => {
    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      const { data, error } = await supabase.functions.invoke('mealie-integration', {
        body: { 
          action: 'generate_sofia_meal_plan',
          dias: 7,
          objetivo: 'equilibrado',
          restricoes: [],
          calorias: 2000,
          userId: user?.id
        }
      });

      if (error) throw error;

      if (data.success) {
        toast.success('Cardápio gerado com receitas do Mealie!');
        onMealPlanGenerate?.(data.mealPlan);
      }
    } catch (error) {
      console.error('Erro ao gerar cardápio:', error);
      toast.error('Erro ao gerar cardápio com Mealie');
    } finally {
      setLoading(false);
    }
  };

  const formatTime = (minutes: number) => {
    if (minutes < 60) return `${minutes}min`;
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}h${mins > 0 ? ` ${mins}min` : ''}`;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <ChefHat className="h-6 w-6 text-orange-500" />
          <h2 className="text-2xl font-bold">Integração Mealie</h2>
        </div>
        <Button onClick={generateSofiaMealPlan} disabled={loading}>
          {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
          Gerar Cardápio com Mealie
        </Button>
      </div>

      {/* Search */}
      <div className="flex gap-2">
        <input
          type="text"
          placeholder="Buscar receitas..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && searchRecipes()}
          className="flex-1 px-3 py-2 border rounded-lg"
        />
        <Button onClick={searchRecipes} disabled={loading}>
          Buscar
        </Button>
        <Button variant="outline" onClick={loadRecipes} disabled={loading}>
          Todas
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-orange-500">{recipes.length}</div>
            <div className="text-sm text-muted-foreground">Receitas Disponíveis</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-green-500">
              {recipes.filter(r => r.nutrition?.calories < 400).length}
            </div>
            <div className="text-sm text-muted-foreground">Baixa Caloria</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-blue-500">
              {recipes.filter(r => (r.prepTime || 0) < 30).length}
            </div>
            <div className="text-sm text-muted-foreground">Preparo Rápido</div>
          </CardContent>
        </Card>
      </div>

      {/* Recipes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {loading ? (
          <div className="col-span-full flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin" />
            <span className="ml-2">Carregando receitas...</span>
          </div>
        ) : (
          recipes.map((recipe) => (
            <Card key={recipe.id} className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between">
                  <CardTitle className="text-lg line-clamp-2">{recipe.name}</CardTitle>
                  {recipe.rating && (
                    <div className="flex items-center">
                      <Star className="h-4 w-4 text-yellow-500 fill-current" />
                      <span className="ml-1 text-sm">{recipe.rating.toFixed(1)}</span>
                    </div>
                  )}
                </div>
                {recipe.description && (
                  <p className="text-sm text-muted-foreground line-clamp-2">
                    {recipe.description}
                  </p>
                )}
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {/* Nutrition Info */}
                  {recipe.nutrition && (
                    <div className="flex flex-wrap gap-1">
                      <Badge variant="secondary">
                        {recipe.nutrition.calories} kcal
                      </Badge>
                      <Badge variant="outline">
                        P: {recipe.nutrition.protein}g
                      </Badge>
                      <Badge variant="outline">
                        C: {recipe.nutrition.carbohydrates}g
                      </Badge>
                      <Badge variant="outline">
                        G: {recipe.nutrition.fat}g
                      </Badge>
                    </div>
                  )}

                  {/* Time and Servings */}
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-1" />
                      {formatTime(recipe.totalTime || recipe.prepTime + recipe.cookTime)}
                    </div>
                    <div className="flex items-center">
                      <Users className="h-4 w-4 mr-1" />
                      {recipe.servings} porções
                    </div>
                  </div>

                  {/* Ingredients Preview */}
                  {recipe.ingredients && recipe.ingredients.length > 0 && (
                    <div>
                      <div className="text-sm font-medium mb-1">Ingredientes:</div>
                      <div className="text-xs text-muted-foreground">
                        {recipe.ingredients.slice(0, 3).map(ing => ing.food).join(', ')}
                        {recipe.ingredients.length > 3 && ` e mais ${recipe.ingredients.length - 3}...`}
                      </div>
                    </div>
                  )}

                  <Button 
                    className="w-full" 
                    size="sm"
                    onClick={() => onRecipeSelect?.(recipe)}
                  >
                    Selecionar Receita
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {!loading && recipes.length === 0 && (
        <div className="text-center py-8">
          <ChefHat className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium mb-2">Nenhuma receita encontrada</h3>
          <p className="text-muted-foreground">
            Verifique se o Mealie está funcionando ou tente buscar por termos diferentes.
          </p>
        </div>
      )}
    </div>
  );
};

export default MealieIntegration;